package com.example.sweproject12;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.*;
import java.time.LocalDate;
import java.util.Scanner;

public class MainStartApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(MainStartApplication.class.getResource("LoginPage.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 800, 500);
        stage.setTitle("Main Page");
        stage.setScene(scene);
        stage.show();

    }

    public static void main(String[] args) {


        launch();
        if (!(Controller.admins.isEmpty() && Controller.users.isEmpty() && Controller.advancedUsers.isEmpty())){

            try (PrintWriter writer = new PrintWriter(new FileWriter("Admin.txt"))) {

                for (Admin admin : Controller.admins) {
                    writer.println("Admin "+ admin.getId() + " " + admin.getEmail() + " " + admin.getPassword() + " " + admin.isGender());
                }
                for (Reservation reservation : Controller.reservations) {
                    if (reservation.getReserver() instanceof Admin)
                        writer.println("Reservations " + reservation.getReserver().getId() + " " + reservation.getReserver().getEmail() + " " + reservation.getReserver().getPassword() + " " + reservation.getReserver().isGender() + " " + reservation.getRoom().getRoomNumber() + " " + reservation.getRoom().getRoomType() + " " + reservation.getRoom().getLocation() + " " + reservation.getRoom().getGender() + " " + reservation.getDate() + " " + reservation.getStatus() + " " + reservation.getTime() );
                }
                for (Event event : Controller.events) {
                    if (event.getEventOrginizer() instanceof Admin)
                        writer.println("Events "+ event.getEventOrginizer().getId() + " " + event.getEventOrginizer().getEmail() + " " + event.getEventOrginizer().getPassword() + " " + event.getEventOrginizer().isGender() + " " + event.getRoom().getRoomNumber() + " " + event.getRoom().getRoomType() + " " + event.getRoom().getLocation() + " " + event.getRoom().getGender() + " " + event.getReservation() + " " + event.getStatus() + " " + event.getReservation().getReserver().getId() + " " + event.getReservation().getReserver().getEmail() + " " + event.getReservation().getReserver().getPassword() + " " + event.getReservation().getReserver().isGender() + " " + event.getReservation().getRoom().getRoomNumber() + " " + event.getReservation().getRoom().getRoomType() + " " + event.getReservation().getRoom().getLocation() + " " + event.getReservation().getRoom().getGender() + " " + event.getReservation().getDate() + " " + event.getReservation().getStatus() + " " + event.getReservation().getTime() + " " + event.getStatus() + " " + event.getCapacity() );
                }
            }
            catch (IOException ex){
                System.out.println(ex.getMessage());
            }
            try (PrintWriter writer = new PrintWriter(new FileWriter("User.txt"))) {
                System.out.println(Controller.users);
                for (User user : Controller.users) {
                    writer.println("User " + user.getId() + " " + user.getEmail() + " " + user.getPassword() + " " + user.isGender());
                }
                for (Reservation reservation : Controller.reservations) {
                    if (reservation.getReserver() instanceof User)
                        writer.println("Reservations " + reservation.getReserver().getId() + " " + reservation.getReserver().getEmail() + " " + reservation.getReserver().getPassword() + " " + reservation.getReserver().isGender() + " " + reservation.getRoom().getRoomNumber() + " " + reservation.getRoom().getRoomType() + " " + reservation.getRoom().getLocation() + " " + reservation.getRoom().getGender() + " " + reservation.getDate() + " " + reservation.getStatus() + " " + reservation.getTime() );
                }
                for (Event event : Controller.events) {
                    if (event.getEventOrginizer() instanceof User)
                        writer.println("Events " + event.getEventOrginizer().getId() + " " + event.getEventOrginizer().getEmail() + " " + event.getEventOrginizer().getPassword() + " " + event.getEventOrginizer().isGender() + " " + event.getRoom().getRoomNumber() + " " + event.getRoom().getRoomType() + " " + event.getRoom().getLocation() + " " + event.getRoom().getGender() + " " + event.getReservation() + " " + event.getStatus() + " " + event.getReservation().getReserver().getId() + " " + event.getReservation().getReserver().getEmail() + " " + event.getReservation().getReserver().getPassword() + " " + event.getReservation().getReserver().isGender() + " " + event.getReservation().getRoom().getRoomNumber() + " " + event.getReservation().getRoom().getRoomType() + " " + event.getReservation().getRoom().getLocation() + " " + event.getReservation().getRoom().getGender() + " " + event.getReservation().getDate() + " " + event.getReservation().getStatus() + " " + event.getReservation().getTime() + " " + event.getStatus() + " " + event.getCapacity() );
                }

            }
            catch (IOException ex){
                System.out.println(ex.getMessage());
            }
            try (PrintWriter writer = new PrintWriter(new FileWriter("AdvancedUser.txt"))) {
                for (AdvancedUser advancedUser : Controller.advancedUsers) {
                    writer.println("AdvancedUser " + advancedUser.getId() + " " + advancedUser.getEmail() + " " + advancedUser.getPassword() + " " + advancedUser.isGender());
                }
                for (Reservation reservation : Controller.reservations) {
                    if (reservation.getReserver() instanceof AdvancedUser)
                        writer.println("Reservations " + reservation.getReserver().getId() + " " + reservation.getReserver().getEmail() + " " + reservation.getReserver().getPassword() + " " + reservation.getReserver().isGender() + " " + reservation.getRoom().getRoomNumber() + " " + reservation.getRoom().getRoomType() + " " + reservation.getRoom().getLocation() + " " + reservation.getRoom().getGender() + " " + reservation.getDate() + " " + reservation.getStatus() + " " + reservation.getTime() );
                }
                for (Event event : Controller.events) {
                    if (event.getEventOrginizer() instanceof AdvancedUser)
                        writer.println("Events " + event.getEventOrginizer().getId() + " " + event.getEventOrginizer().getEmail() + " " + event.getEventOrginizer().getPassword() + " " + event.getEventOrginizer().isGender() + " " + event.getRoom().getRoomNumber() + " " + event.getRoom().getRoomType() + " " + event.getRoom().getLocation() + " " + event.getRoom().getGender() + " " + event.getReservation() + " " + event.getStatus() + " " + event.getReservation().getReserver().getId() + " " + event.getReservation().getReserver().getEmail() + " " + event.getReservation().getReserver().getPassword() + " " + event.getReservation().getReserver().isGender() + " " + event.getReservation().getRoom().getRoomNumber() + " " + event.getReservation().getRoom().getRoomType() + " " + event.getReservation().getRoom().getLocation() + " " + event.getReservation().getRoom().getGender() + " " + event.getReservation().getDate() + " " + event.getReservation().getStatus() + " " + event.getReservation().getTime() + " " + event.getStatus() + " " + event.getCapacity() );
                }

            }
            catch (IOException ex){
                System.out.println(ex.getMessage());
            }
            try (PrintWriter writer = new PrintWriter(new FileWriter("Room.txt"))) {
                for (Room room : Controller.rooms) {
                    writer.println(room.getRoomNumber() + " " + room.getRoomType() + " " + room.getLocation() + " " + room.getGender());
                }
            }
            catch (IOException ex){
                System.out.println(ex.getMessage());
            }
        }

    }
}